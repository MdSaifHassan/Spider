"use client";
import React from "react";
import { useFormik } from "formik";
import { Box, TextField, Typography } from "@mui/material";
import { DatePicker, TimePicker } from "@mui/x-date-pickers";
import { formValidationSchema } from "../../../utils/formvalidation/ServicesForm";
import CustomAutoComplete from "../../../components/Autocomplete/CustumAutocomplete";
import CaspianButton from "../../../components/Button/Button";

const Form = () => {
  const formik = useFormik({
    initialValues: {
      category: "",
      service: "",
      date: null,
      time: null,
      description: "",
    },
    validationSchema: formValidationSchema,
    onSubmit: (values) => {
      console.log("Submitted Data:", values);
    },
  });

  const handleFieldChange = (field, value) => {
    formik.setFieldValue(field, value);
  };

  const getError = (field) =>
    Boolean(formik.touched[field] && formik.errors[field]);

  return (
    <Box
      component="form"
      onSubmit={formik.handleSubmit}
      sx={{
        maxWidth: 400,
        mx: "auto",
        background: "#f9f9f9",
        borderRadius: 2,
        padding: 3,
      }}
    >
      <Typography variant="h5" fontWeight="bold" mb={2}>
        Service Selection Form
      </Typography>

      <Box mb={2}>
        <CustomAutoComplete
          options={[{ value: "Category1", label: "Category 1" }, { value: "Category2", label: "Category 2" }]}
          label="Select Category"
          value={formik.values.category}
          onChange={(e, value) => handleFieldChange("category", value?.value)}
          placeholder="Select a category"
          textFieldProps={{
            error: getError("category"),
            size: "small",
          }}
        />
      </Box>

      <Box mb={2}>
        <CustomAutoComplete
          options={[{ value: "Service1", label: "Service 1" }, { value: "Service2", label: "Service 2" }]}
          label="Select Service"
          value={formik.values.service}
          onChange={(e, value) => handleFieldChange("service", value?.value)}
          placeholder="Select a service"
          textFieldProps={{
            error: getError("service"),
            size: "small",
          }}
        />
      </Box>

      <Box mb={2}>
        <DatePicker
          label="Select Date"
          value={formik.values.date}
          onChange={(value) => handleFieldChange("date", value)}
          slotProps={{
            textField: {
              fullWidth: true,
              error: getError("date"),
              helperText: formik.errors.date,
              size: "small",
            },
          }}
        />
      </Box>

      <Box mb={2}>
        <TimePicker
          label="Select Time"
          value={formik.values.time}
          onChange={(value) => handleFieldChange("time", value)}
          slotProps={{
            textField: {
              fullWidth: true,
              error: getError("time"),
              helperText: formik.errors.time,
              size: "small",
            },
          }}
        />
      </Box>

      <Box mb={2}>
        <TextField
          label="Description"
          multiline
          rows={3}
          value={formik.values.description}
          onChange={(e) => handleFieldChange("description", e.target.value)}
          fullWidth
          error={getError("description")}
          helperText={formik.errors.description}
          size="small"
        />
      </Box>

      <CaspianButton
        fullWidth
        type="submit"
        title="Submit"
        sx={{ background: "#34A76C", color: "#fff" }}
      />
    </Box>
  );
};

export default Form;



// "use client";
// import React, { useState } from "react";
// import { useSelector, useDispatch } from "react-redux";
// import { useFormik } from "formik";
// import { Box, TextField, Typography } from "@mui/material";
// import { DatePicker, TimePicker } from "@mui/x-date-pickers";
// import { formValidationSchema } from "../../../utils/formvalidation/ServicesForm";
// import { updateForm } from "../../../utils/slices/formSlice";
// import CustomAutoComplete from "../../../components/Autocomplete/CustumAutocomplete";
// import CaspianButton from "@/src/components/Button/Button";
// import LoginModal from "@/src/module/Login/page";

// const Form = () => {
//   const dispatch = useDispatch();
//   const { categories, services, formData, isAuthenticated } = useSelector(
//     (state) => state.form
//   );

//   const [isLoginModalOpen, setIsLoginModalOpen] = useState(false);

//   const formik = useFormik({
//     initialValues: {
//       ...formData,
//       date: formData.date ? new Date(formData.date) : null,
//       time: formData.time ? new Date(formData.time) : null,
//     },
//     validationSchema: formValidationSchema,
//     onSubmit: (values) => {
//       if (isAuthenticated) {
//         console.log("Submitted Data:", values);
//       } else {
//         setIsLoginModalOpen(true);
//       }
//     },
//   });

//   const handleFieldChange = (field, value) => {
//     const serializedValue =
//       field === "date" || field === "time" ? value?.toISOString() : value;
//     formik.setFieldValue(field, serializedValue);
//     dispatch(updateForm({ [field]: serializedValue }));
//   };

//   const getError = (field) =>
//     Boolean(formik.touched[field] && formik.errors[field]);

//   const closeModal = () => {
//     setIsLoginModalOpen(false);
//   };

//   return (
//     <>
//       <Box
//         component="form"
//         onSubmit={formik.handleSubmit}
//         sx={{
//           maxWidth: 350,
//           mx: "auto",
//           background: "#EEEEEEE5",
//           borderRadius: 2,
//           padding: 2,
//         }}
//       >
//         <Typography variant="h5" fontWeight={"bold"} mb={2}>
//           Select Our Services
//         </Typography>

//         <Box mb={2}>
//           <CustomAutoComplete
//             options={categories}
//             label="Select Category"
//             value={formik.values.category}
//             onChange={(e, value) => handleFieldChange("category", value?.value)}
//             placeholder="Select a category"
//             textFieldProps={{
//               error: getError("category"),
//               size: "small",
//               sx: getError("category") ? { borderColor: "red" } : {},
//             }}
//           />
//         </Box>

//         <Box mb={2}>
//           <CustomAutoComplete
//             options={services}
//             label="Select Services"
//             value={formik.values.service}
//             onChange={(e, value) => handleFieldChange("service", value?.value)}
//             placeholder="Select a service"
//             textFieldProps={{
//               error: getError("service"),
//               size: "small",
//               sx: getError("service") ? { borderColor: "red" } : {},
//             }}
//           />
//         </Box>

//         <Box mb={2}>
//           <DatePicker
//             label="Select Date"
//             value={formik.values.date ? new Date(formik.values.date) : null}
//             onChange={(value) => handleFieldChange("date", value)}
//             minDate={new Date()}
//             slotProps={{
//               textField: {
//                 fullWidth: true,
//                 error: getError("date"),
//                 size: "small",
//                 sx: getError("date") ? { borderColor: "red" } : {},
//               },
//             }}
//           />
//         </Box>

//         <Box mb={2}>
//           <TimePicker
//             label="Select Time"
//             value={formik.values.time ? new Date(formik.values.time) : null}
//             onChange={(value) => handleFieldChange("time", value)}
//             slotProps={{
//               textField: {
//                 fullWidth: true,
//                 error: getError("time"),
//                 size: "small",
//                 sx: getError("time") ? { borderColor: "red" } : {},
//               },
//             }}
//           />
//         </Box>

//         <Box mb={2}>
//           <TextField
//             label="Description"
//             multiline
//             rows={3}
//             value={formik.values.description}
//             onChange={(e) => handleFieldChange("description", e.target.value)}
//             fullWidth
//             error={getError("description")}
//             size="small"
//             sx={getError("description") ? { borderColor: "red" } : {}}
//           />
//         </Box>

//         <CaspianButton
//           size="medium"
//           title="Submit"
//           sx={{
//             background: "#34A76C",
//             color: "#fff",
//             padding: "0.4rem 5rem",
//             fontWeight: "bold",
//           }}
//           onClick={(e) => {
//             e.preventDefault();
//             if (isAuthenticated) {
//               formik.handleSubmit();
//             } else {
//               setIsLoginModalOpen(true);
//             }
//           }}
//           type={isAuthenticated ? "submit" : "button"}
//         />


//       </Box>

//       {!isAuthenticated && <LoginModal open={isLoginModalOpen} onClose={closeModal} />}
//     </>
//   );
// };

// export default Form;
